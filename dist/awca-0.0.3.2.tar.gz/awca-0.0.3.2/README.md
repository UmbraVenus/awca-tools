# awca-tools
 tools and functions for AWCA

## Sample Usage
### from awca import summarization
summarization.summarize()
Input: Text
Output Text

### from awca import paraphrasing
paraphrasing.paraphrase()
Input: Text
Output: Text

### from awca import ocr
ocr.populate_csv()
Input: a list of files
Output: a csv file